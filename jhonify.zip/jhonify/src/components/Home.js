import { Form, useNavigate } from "react-router-dom";
import logo from "../assets/logo.jpg";
import maroon5 from "../assets/music/maroon5.mp3";
import TheChainsmokers from "../assets/music/TheChainsmokers.mp3";

function Home() {
  //hook para navegar entre pantallas
  const navigate = useNavigate();

  const songs = [
    {
      title: "girl like you",
      artist: "Maroon 5",
      url: maroon5
      
    },
    {
      title: "don't let me down",
      artist: "the chainsmokers",
      url: TheChainsmokers
      
    },
  ];

  // funcion para ir al reproductor
  const goToPlayer = (song) => {
    navigate("/player", { state: { song } });
  };

  return (
     <div style={{ padding: 20, textAlign: "center" }}>
        <img 
  src={logo} 
  alt="logo"
  style={{ width: "120px", center: "10px" }}

/><h2 style={{ marginTop: "10px", color: "#f9fcfa" }}>
      canciones populares
    </h2>
      

      {songs.map((song, i) => (
        <div
          key={i}
          onClick={() => goToPlayer(song)}
          style={{
            border: "1px solid #333",
            margin: 10,
            padding: 10,
            cursor: "pointer",
          }}
        >
          <h3>{song.title}</h3>
          <p>{song.artist}</p>
        </div>
      ))}
    </div>
  );
}

export default Home;