import { useLocation } from "react-router-dom";
import { useRef } from "react";
import { useNavigate } from "react-router-dom";

function Player() {
  // obtener datos enviados desde Home
  const location = useLocation();
  const song = location.state?.song;
  const navigate = useNavigate();

  // Referencia al audio
  const audioRef = useRef(null);

  // Funcion para reproducir la cancion
  const play = () => {
    audioRef.current.src = song.url;
    audioRef.current.play();
  };

  // Funcion para pausar la cancion
  const pause = () => {
    audioRef.current.pause();
  };

  return (
   <div style={{ padding: 20, textAlign: "center" }}>
      <h2>{song?.title}</h2>
      <p>{song?.artist}</p>

      <audio ref={audioRef} controls style={{ width: "75%" }} />

      <br />

      <button onClick={play}>▶️ Play</button>
      <button onClick={pause}>⏸️ Pause</button>
      <button onClick={() => navigate("/")}>⬅️ Volver</button>
    </div>
  );
}

export default Player;