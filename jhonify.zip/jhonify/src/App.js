import { BrowserRouter, Routes, Route } from "react-router-dom";

// Importamos paginas
import Home from "./components/Home";
import Player from "./components/Player";

// Configuracion de navegacion 
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/player" element={<Player />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;